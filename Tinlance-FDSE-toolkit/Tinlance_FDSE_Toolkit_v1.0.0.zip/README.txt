Tinlance FDSE Toolkit v1.0.0
==============================
Built: 2026-06-01
By: Tinlance Limited (RC: 7962164) | tinlance.com

CONTENTS
─────────────────────────────────────────────────────
component_1_report_generator/
  report_generator.py       PDF + Word + Excel report engine
                            Run: python report_generator.py --demo

component_2_airgap_bundle/
  build_airgap_bundle.py    USB offline bundle builder
                            Run: python build_airgap_bundle.py --output ./bundle

component_3_gui_launcher/
  toolkit_gui.py            Unified Tkinter GUI launcher
                            Run: python toolkit_gui.py

engagement_docs/
  Tinlance_Pilot_Agreement.docx       Client contract template
  Tinlance_Discovery_Call_Script.docx 30-min call guide + objection handling
  Tinlance_Scope_Template.docx        One-page proposal template
  Tinlance_Handoff_Checklist.docx     End-of-engagement sign-off checklist

demo_reports/
  TinlanceReport_Demo_PDF.pdf         Sample enterprise security report (PDF)
  TinlanceReport_Demo_Word.docx       Sample enterprise security report (Word)
  TinlanceReport_Demo_Excel.xlsx      Sample enterprise findings tracker (Excel)

QUICK START
─────────────────────────────────────────────────────
1. Generate a demo report:
   pip install reportlab openpyxl python-docx
   python component_1_report_generator/report_generator.py --demo --out ./reports

2. Launch the GUI:
   python component_3_gui_launcher/toolkit_gui.py

3. Build air-gap USB bundle:
   python component_2_airgap_bundle/build_airgap_bundle.py --output ./usb_bundle

LIVE SYSTEMS
─────────────────────────────────────────────────────
FusionOps Dashboard:  http://13.50.16.19/dashboard
Health Check:         http://13.50.16.19/health
API Documentation:    http://13.50.16.19/docs
Detection Endpoint:   http://13.50.16.19/detect/scenario

ThreatFade Source:    github.com/LloydCoder/tinlance-threatfade

SUPPORT
─────────────────────────────────────────────────────
Email:   nwachukwuchinaemerem8@gmail.com
Website: tinlance.com
GitHub:  github.com/LloydCoder | github.com/Tinlance
